﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ReseData : MonoBehaviour
{
    public void ClearData()
    {
        SaveControler.Instance.ClearSave();

    }

}
